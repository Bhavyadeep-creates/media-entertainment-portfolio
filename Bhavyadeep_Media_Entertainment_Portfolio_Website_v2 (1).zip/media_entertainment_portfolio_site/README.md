# Bhavyadeep Singh — Media & Entertainment Portfolio

A static, responsive portfolio website designed for GitHub Pages.

## Included projects
1. JioStar — Ad Sales & Revenue Strategy (PPT + Excel)
2. Lahori Zeera × Shark Tank India (PPT + Excel)
3. Pilgrim × Zee Entertainment (PPT; Excel workbook placeholder)

## Before publishing
1. Replace `YOUR_EMAIL@example.com` in `index.html` with the email address you want recruiters to use.
2. Replace `YOUR-LINKEDIN` with your LinkedIn profile slug.
3. Add the Pilgrim Excel workbook to `assets/` and update the pending workbook block in `index.html` to a download link.
4. Review the public-facing content and files before publishing. All project assumptions and simulated figures should remain clearly labelled.

## Publish with GitHub Pages
1. Create a new public GitHub repository, for example `media-entertainment-portfolio`.
2. Upload the contents of this folder (not the ZIP itself) to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**.
5. Select branch `main` and folder `/ (root)`, then save.
6. GitHub will provide your public website URL after deployment.

No build tools or package installation are required.
